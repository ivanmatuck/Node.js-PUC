//console.log('estou em -> modulo.js')

const sobrenome = 'Araujo'

const calculoMaluco = (numero, valorIncrementado) =>{
    return (numero * valorIncrementado + 2) / 10
}

module.exports = calculoMaluco