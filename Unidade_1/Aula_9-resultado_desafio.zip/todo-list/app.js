const log = require('./util')

console.log('app.js')
log('primeira mensagem de log')
log('segunda mensagem de log')

